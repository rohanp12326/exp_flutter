import 'package:equatable/equatable.dart';

class Category extends Equatable {
  final String label;

  const Category({required this.label});

  @override
  List<Object?> get props => [label];
}

import 'package:dartz/dartz.dart';
import 'package:my_project/core/error/failure.dart';
import 'package:my_project/features/home/domain/entities/category.dart';
import 'package:my_project/features/home/domain/entities/featured.dart';
import 'package:my_project/features/home/domain/entities/recipe.dart';

abstract class HomeRepository {
  Future<Either<Failure, List<Featured>>> getFeatured();
  Future<Either<Failure, List<Category>>> getCategories();
  Future<Either<Failure, List<Recipe>>> getPopularRecipes(String category);
}

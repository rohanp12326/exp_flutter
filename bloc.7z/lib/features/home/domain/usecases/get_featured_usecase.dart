import 'package:dartz/dartz.dart';
import 'package:my_project/core/error/failure.dart';
import 'package:my_project/features/home/domain/entities/featured.dart';
import 'package:my_project/features/home/domain/repositories/home_repository.dart';

class GetFeaturedUseCase {
  final HomeRepository repository;

  GetFeaturedUseCase({required this.repository});

  Future<Either<Failure, List<Featured>>> call() => repository.getFeatured();
}

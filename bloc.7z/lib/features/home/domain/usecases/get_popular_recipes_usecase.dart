import 'package:dartz/dartz.dart';
import 'package:my_project/core/error/failure.dart';
import 'package:my_project/features/home/domain/entities/recipe.dart';
import 'package:my_project/features/home/domain/repositories/home_repository.dart';

class GetPopularRecipesUseCase {
  final HomeRepository repository;

  GetPopularRecipesUseCase({required this.repository});

  Future<Either<Failure, List<Recipe>>> call(String category) => repository.getPopularRecipes(category);
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:my_project/features/home/presentation/bloc/home_bloc.dart';
import 'package:my_project/features/home/presentation/bloc/home_event.dart';
import 'package:my_project/features/home/presentation/pages/home_screen.dart';
import 'package:my_project/features/home/presentation/widgets/custom_bottom_nav_bar.dart';
import 'package:my_project/features/home/presentation/widgets/custom_floating_button.dart';
import 'package:my_project/injection/injector.dart';

class CombinedScreens extends StatelessWidget {
  const CombinedScreens({super.key});
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => sl<HomeBloc>()..add(LoadHomeData()),
      child: Scaffold(
        body: const HomeScreen(),
        bottomNavigationBar: const CustomBottomNavBar(),
        floatingActionButton: const CustomFloatingButton(),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:my_project/core/constants/size_utils.dart';
import 'package:my_project/features/home/presentation/bloc/home_bloc.dart';
import 'package:my_project/features/home/presentation/bloc/home_event.dart';
import 'package:my_project/features/home/presentation/bloc/home_state.dart';
import 'package:my_project/features/home/presentation/widgets/category_section.dart';
import 'package:my_project/features/home/presentation/widgets/custom_header.dart';
import 'package:my_project/features/home/presentation/widgets/featured_section.dart';
import 'package:my_project/features/home/presentation/widgets/popular_recipes_section.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HomeBloc, HomeState>(
      builder: (context, state) {
        if (state is HomeLoading || state is HomeInitial) {
          return const Center(child: CircularProgressIndicator());
        } else if (state is HomeLoaded) {
          return SafeArea(
            child: LayoutBuilder(builder: (context, constraints) {
              return SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: BoxConstraints(minHeight: constraints.maxHeight),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const CustomHeader(),
                    SizedBox(height: SizeUtils.scaleHeight(context, 16)),
                    FeaturedSection(featuredList: state.featuredList),
                    SizedBox(height: SizeUtils.scaleHeight(context, 16)),
                    CategorySection(
                      selectedCategory: state.selectedCategory,
                      categories: state.categories,
                      onCategorySelected: (c) => context.read<HomeBloc>().add(SelectCategory(c)),
                    ),
                    SizedBox(height: SizeUtils.scaleHeight(context, 16)),
                    PopularRecipesSection(popularRecipes: state.popularRecipes),
                    SizedBox(height: SizeUtils.scaleHeight(context, 80)),
                  ]),
                ),
              );
            }),
          );
        } else if (state is HomeError) {
          return Center(child: Text(state.message));
        }
        return const SizedBox.shrink();
      },
    );
  }
}

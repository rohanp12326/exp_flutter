import 'package:bloc/bloc.dart';
import 'package:dartz/dartz.dart';
import 'package:my_project/core/error/failure.dart';
import 'package:my_project/features/home/domain/usecases/get_categories_usecase.dart';
import 'package:my_project/features/home/domain/usecases/get_featured_usecase.dart';
import 'package:my_project/features/home/domain/usecases/get_popular_recipes_usecase.dart';
import 'package:my_project/features/home/presentation/bloc/home_event.dart';
import 'package:my_project/features/home/presentation/bloc/home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final GetFeaturedUseCase getFeaturedUseCase;
  final GetCategoriesUseCase getCategoriesUseCase;
  final GetPopularRecipesUseCase getPopularRecipesUseCase;

  HomeBloc({
    required this.getFeaturedUseCase,
    required this.getCategoriesUseCase,
    required this.getPopularRecipesUseCase,
  }) : super(HomeInitial()) {
    on<LoadHomeData>(_onLoadHomeData);
    on<SelectCategory>(_onSelectCategory);
  }

  Future<void> _onLoadHomeData(LoadHomeData event, Emitter<HomeState> emit) async {
    emit(HomeLoading());
    final fRes = await getFeaturedUseCase();
    final cRes = await getCategoriesUseCase();
    cRes.fold(
      (f) => emit(HomeError(f.message)),
      (categories) async {
        final initial = categories.isNotEmpty ? categories.first.label : '';
        final pRes = await getPopularRecipesUseCase(initial);
        pRes.fold(
          (f) => emit(HomeError(f.message)),
          (recipes) => emit(HomeLoaded(
            featuredList: fRes.getOrElse(() => []),
            categories: categories,
            popularRecipes: recipes,
            selectedCategory: initial,
          )),
        );
      },
    );
  }

  Future<void> _onSelectCategory(SelectCategory event, Emitter<HomeState> emit) async {
    if (state is HomeLoaded) {
      final current = state as HomeLoaded;
      emit(current.copyWith(popularRecipes: []));
      final res = await getPopularRecipesUseCase(event.category);
      res.fold(
        (f) => emit(HomeError(f.message)),
        (recipes) => emit(current.copyWith(selectedCategory: event.category, popularRecipes: recipes)),
      );
    }
  }
}

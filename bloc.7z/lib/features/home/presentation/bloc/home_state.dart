import 'package:equatable/equatable.dart';
import 'package:my_project/features/home/domain/entities/category.dart';
import 'package:my_project/features/home/domain/entities/featured.dart';
import 'package:my_project/features/home/domain/entities/recipe.dart';

abstract class HomeState extends Equatable {
  const HomeState();
  @override
  List<Object?> get props => [];
}

class HomeInitial extends HomeState {}

class HomeLoading extends HomeState {}

class HomeLoaded extends HomeState {
  final List<Featured> featuredList;
  final List<Category> categories;
  final List<Recipe> popularRecipes;
  final String selectedCategory;

  const HomeLoaded({
    required this.featuredList,
    required this.categories,
    required this.popularRecipes,
    required this.selectedCategory,
  });

  HomeLoaded copyWith({
    List<Featured>? featuredList,
    List<Category>? categories,
    List<Recipe>? popularRecipes,
    String? selectedCategory,
  }) {
    return HomeLoaded(
      featuredList: featuredList ?? this.featuredList,
      categories: categories ?? this.categories,
      popularRecipes: popularRecipes ?? this.popularRecipes,
      selectedCategory: selectedCategory ?? this.selectedCategory,
    );
  }

  @override
  List<Object?> get props => [featuredList, categories, popularRecipes, selectedCategory];
}

class HomeError extends HomeState {
  final String message;
  const HomeError(this.message);
  @override
  List<Object?> get props => [message];
}

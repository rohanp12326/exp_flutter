import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/size_utils.dart';

class RecipeCard extends StatelessWidget {
  final String imagePath;
  final String title;
  final String calories;
  final String time;
  const RecipeCard({
    required this.imagePath,
    required this.title,
    required this.calories,
    required this.time,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return GestureDetector(
      onTap: () {},
      child: AspectRatio(
        aspectRatio: 3 / 4,
        child: Container(
          decoration: BoxDecoration(
            color: ColorPalette.background,
            borderRadius: BorderRadius.circular(16),
            boxShadow: const [BoxShadow(color: Color.fromRGBO(5,51,54,0.1), offset: Offset(0,2), blurRadius:16)],
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Expanded(
              flex: 6,
              child: Stack(children: [
                ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(16)), child: Image.asset(imagePath, fit: BoxFit.cover)),
                Positioned(
                  top: SizeUtils.scaleHeight(context, 8),
                  right: SizeUtils.scaleWidth(context, 8),
                  child: GestureDetector(
                    onTap: () {},
                    child: Image.asset('assets/images/favourite_icon.png', height: h * 0.03),
                  ),
                ),
              ]),
            ),
            Expanded(
              flex: 4,
              child: Padding(
                padding: EdgeInsets.all(SizeUtils.scaleWidth(context, 8)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, style: TextStyle(fontSize: h * 0.018, fontWeight: FontWeight.bold, color: ColorPalette.textPrimary), maxLines: 2, overflow: TextOverflow.ellipsis),
                  const Spacer(),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Row(children: [
                      Image.asset('assets/images/calories_icon.png', height: h * 0.02),
                      SizedBox(width: SizeUtils.scaleWidth(context, 4)),
                      Text(calories, style: TextStyle(fontSize: h * 0.015, color: ColorPalette.textSecondary)),
                    ]),
                    Row(children: [
                      Image.asset('assets/images/proteins_icon.png', height: h * 0.02),
                      SizedBox(width: SizeUtils.scaleWidth(context, 4)),
                      Text(time, style: TextStyle(fontSize: h * 0.015, color: ColorPalette.textSecondary)),
                    ]),
                  ]),
                ]),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

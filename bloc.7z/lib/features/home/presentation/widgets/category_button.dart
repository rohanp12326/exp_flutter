import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/size_utils.dart';

class CategoryButton extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  const CategoryButton({
    required this.label,
    required this.isSelected,
    required this.onTap,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: SizeUtils.scaleWidth(context, 4)),
          padding: EdgeInsets.symmetric(vertical: SizeUtils.scaleHeight(context, 8)),
          decoration: BoxDecoration(
            color: isSelected ? ColorPalette.primary : ColorPalette.secondary,
            borderRadius: BorderRadius.circular(32),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                fontSize: SizeUtils.scaleHeight(context, 18),
                color: isSelected ? Colors.white : ColorPalette.textPrimary,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

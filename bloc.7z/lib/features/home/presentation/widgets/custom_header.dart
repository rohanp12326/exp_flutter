import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/size_utils.dart';

class CustomHeader extends StatelessWidget {
  const CustomHeader({super.key});
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: SizeUtils.scaleWidth(context, 16),
        vertical: SizeUtils.scaleHeight(context, 8),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Image.asset('assets/images/sun_icon.png', height: h * 0.025),
            SizedBox(width: SizeUtils.scaleWidth(context, 8)),
            Text('Good Morning', style: TextStyle(fontSize: h * 0.02, color: ColorPalette.textPrimary)),
          ]),
          SizedBox(height: SizeUtils.scaleHeight(context, 4)),
          Text('Alena Sabyan', style: TextStyle(fontSize: h * 0.027, fontWeight: FontWeight.w800, color: ColorPalette.textPrimary)),
        ]),
        Row(children: [
          IconButton(icon: Image.asset('assets/images/cart_icon.png'), iconSize: h * 0.03, onPressed: () {}),
          IconButton(icon: Image.asset('assets/images/bottom_profile_icon.png'), iconSize: h * 0.03, onPressed: () {}),
        ]),
      ]),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/size_utils.dart';
import 'package:my_project/features/home/domain/entities/category.dart';
import 'package:my_project/features/home/presentation/widgets/category_button.dart';

class CategorySection extends StatelessWidget {
  final String selectedCategory;
  final List<Category> categories;
  final Function(String) onCategorySelected;
  const CategorySection({
    required this.selectedCategory,
    required this.categories,
    required this.onCategorySelected,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: SizeUtils.scaleWidth(context, 16)),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Category', style: TextStyle(fontSize: h * 0.022, fontWeight: FontWeight.w800, color: ColorPalette.textPrimary)),
          GestureDetector(onTap: () {}, child: Text('See All', style: TextStyle(fontSize: h * 0.015, fontWeight: FontWeight.w800, color: ColorPalette.primary))),
        ]),
        SizedBox(height: SizeUtils.scaleHeight(context, 8)),
        Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: categories.map((c) {
          return CategoryButton(label: c.label, isSelected: selectedCategory == c.label, onTap: () => onCategorySelected(c.label));
        }).toList()),
      ]),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';

class CustomFloatingButton extends StatelessWidget {
  const CustomFloatingButton({super.key});
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size.height * 0.063;
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        color: Color.fromRGBO(3,38,40,1),
        boxShadow: [BoxShadow(color: Color.fromRGBO(3,3,25,0.2), blurRadius:30)],
      ),
      child: Center(child: Image.asset('assets/images/chef_icon.png', height: MediaQuery.of(context).size.height * 0.03)),
    );
  }
}

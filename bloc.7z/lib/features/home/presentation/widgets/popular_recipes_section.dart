import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/size_utils.dart';
import 'package:my_project/features/home/domain/entities/recipe.dart';
import 'package:my_project/features/home/presentation/widgets/recipe_card.dart';

class PopularRecipesSection extends StatelessWidget {
  final List<Recipe> popularRecipes;
  const PopularRecipesSection({required this.popularRecipes, super.key});
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: SizeUtils.scaleWidth(context, 16)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Popular Recipes', style: TextStyle(fontSize: h * 0.022, fontWeight: FontWeight.w800, color: ColorPalette.textPrimary)),
          GestureDetector(onTap: () {}, child: Text('See All', style: TextStyle(fontSize: h * 0.015, fontWeight: FontWeight.w800, color: ColorPalette.primary))),
        ]),
        SizedBox(height: SizeUtils.scaleHeight(context, 8)),
        SizedBox(
          height: h * 0.25,
          child: Scrollbar(
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: popularRecipes.length,
              separatorBuilder: (_, __) => SizedBox(width: SizeUtils.scaleWidth(context, 16)),
              itemBuilder: (_, i) {
                final r = popularRecipes[i];
                return RecipeCard(imagePath: r.imagePath, title: r.title, calories: r.calories, time: r.time);
              },
            ),
          ),
        ),
      ]),
    );
  }
}

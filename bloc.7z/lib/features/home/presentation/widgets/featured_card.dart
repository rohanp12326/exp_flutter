import 'package:flutter/material.dart';
import 'package:my_project/core/constants/size_utils.dart';

class FeaturedCard extends StatelessWidget {
  final String imagePath;
  final String title;
  final String creator;
  final String time;
  const FeaturedCard({
    required this.imagePath,
    required this.title,
    required this.creator,
    required this.time,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return GestureDetector(
      onTap: () {},
      child: AspectRatio(
        aspectRatio: 16 / 9,
        child: Container(
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(16)),
          child: Stack(children: [
            ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.asset(imagePath, fit: BoxFit.cover, width: double.infinity)),
            Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), gradient: LinearGradient(colors: [Colors.transparent, Colors.black54], begin: Alignment.topCenter, end: Alignment.bottomCenter))),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(fontSize: h * 0.02, fontWeight: FontWeight.bold, color: Colors.white)),
                const Spacer(),
                Row(children: [
                  CircleAvatar(radius: h * 0.015, backgroundImage: const AssetImage('assets/images/user_image_1.png')),
                  SizedBox(width: SizeUtils.scaleWidth(context, 8)),
                  Text(creator, style: TextStyle(fontSize: h * 0.015, color: Colors.white)),
                  const Spacer(),
                  Text(time, style: TextStyle(fontSize: h * 0.015, color: Colors.white)),
                ]),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

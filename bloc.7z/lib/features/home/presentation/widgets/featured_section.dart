import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/size_utils.dart';
import 'package:my_project/features/home/domain/entities/featured.dart';
import 'package:my_project/features/home/presentation/widgets/featured_card.dart';

class FeaturedSection extends StatelessWidget {
  final List<Featured> featuredList;
  const FeaturedSection({required this.featuredList, super.key});
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: SizeUtils.scaleWidth(context, 16)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Featured', style: TextStyle(fontSize: h * 0.022, fontWeight: FontWeight.w800, color: ColorPalette.textPrimary)),
        SizedBox(height: SizeUtils.scaleHeight(context, 8)),
        SizedBox(
          height: h * 0.25,
          child: Scrollbar(
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: featuredList.length,
              separatorBuilder: (_, __) => SizedBox(width: SizeUtils.scaleWidth(context, 16)),
              itemBuilder: (_, i) {
                final f = featuredList[i];
                return FeaturedCard(imagePath: f.imagePath, title: f.title, creator: f.creator, time: f.time);
              },
            ),
          ),
        ),
      ]),
    );
  }
}

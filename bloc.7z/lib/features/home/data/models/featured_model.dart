import 'package:my_project/features/home/domain/entities/featured.dart';

class FeaturedModel {
  final String imagePath;
  final String title;
  final String creator;
  final String time;

  const FeaturedModel({
    required this.imagePath,
    required this.title,
    required this.creator,
    required this.time,
  });

  Featured toEntity() => Featured(imagePath: imagePath, title: title, creator: creator, time: time);

  static List<FeaturedModel> getMockedList() => const [
        FeaturedModel(
          imagePath: 'assets/images/featured_card_1.png',
          title: 'Asian white noodle with extra seafood',
          creator: 'James Spader',
          time: '20 Min',
        ),
        FeaturedModel(
          imagePath: 'assets/images/featured_card_2.png',
          title: 'Healthy Taco Salad with fresh vegetable',
          creator: 'Olivia Rizka',
          time: '15 Min',
        ),
      ];
}

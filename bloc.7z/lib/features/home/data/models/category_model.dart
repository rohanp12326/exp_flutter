import 'package:my_project/features/home/domain/entities/category.dart';

class CategoryModel {
  final String label;

  const CategoryModel({required this.label});

  Category toEntity() => Category(label: label);

  static List<CategoryModel> getMockedList() => const [
        CategoryModel(label: 'Breakfast'),
        CategoryModel(label: 'Lunch'),
        CategoryModel(label: 'Dinner'),
      ];
}

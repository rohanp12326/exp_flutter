import 'package:my_project/features/home/domain/entities/recipe.dart';

class RecipeModel {
  final String imagePath;
  final String title;
  final String calories;
  final String time;

  const RecipeModel({
    required this.imagePath,
    required this.title,
    required this.calories,
    required this.time,
  });

  Recipe toEntity() => Recipe(imagePath: imagePath, title: title, calories: calories, time: time);

  static List<RecipeModel> getMockedListByCategory(String category) {
    switch (category) {
      case 'Breakfast':
        return const [
          RecipeModel(
            imagePath: 'assets/images/popular_recipe1.png',
            title: 'Healthy Taco Salad with fresh vegetable',
            calories: '120 Kcal',
            time: '20 Min',
          ),
          RecipeModel(
            imagePath: 'assets/images/popular_recipe2.png',
            title: 'Japanese-style Pancakes Recipe',
            calories: '64 Kcal',
            time: '12 Min',
          ),
        ];
      case 'Lunch':
        return const [
          RecipeModel(
            imagePath: 'assets/images/popular_recipe3.png',
            title: 'Grilled Chicken Salad',
            calories: '200 Kcal',
            time: '25 Min',
          ),
          RecipeModel(
            imagePath: 'assets/images/popular_recipe4.png',
            title: 'Pasta Primavera',
            calories: '350 Kcal',
            time: '30 Min',
          ),
        ];
      case 'Dinner':
        return const [
          RecipeModel(
            imagePath: 'assets/images/popular_recipe1.png',
            title: 'Steak with Vegetables',
            calories: '500 Kcal',
            time: '40 Min',
          ),
          RecipeModel(
            imagePath: 'assets/images/popular_recipe2.png',
            title: 'Seafood Paella',
            calories: '600 Kcal',
            time: '50 Min',
          ),
        ];
      default:
        return [];
    }
  }
}

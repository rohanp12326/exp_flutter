import 'package:dartz/dartz.dart';
import 'package:my_project/core/error/failure.dart';
import 'package:my_project/features/home/data/data_sources/home_remote_data_source.dart';
import 'package:my_project/features/home/data/models/category_model.dart';
import 'package:my_project/features/home/data/models/featured_model.dart';
import 'package:my_project/features/home/data/models/recipe_model.dart';
import 'package:my_project/features/home/domain/entities/category.dart';
import 'package:my_project/features/home/domain/entities/featured.dart';
import 'package:my_project/features/home/domain/entities/recipe.dart';
import 'package:my_project/features/home/domain/repositories/home_repository.dart';

class HomeRepositoryImpl implements HomeRepository {
  final HomeRemoteDataSource remoteDataSource;

  HomeRepositoryImpl({required this.remoteDataSource});

  @override
  Future<Either<Failure, List<Featured>>> getFeatured() async {
    try {
      final models = await remoteDataSource.fetchFeatured();
      return Right(models.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<Category>>> getCategories() async {
    try {
      final models = await remoteDataSource.fetchCategories();
      return Right(models.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<Recipe>>> getPopularRecipes(String category) async {
    try {
      final models = await remoteDataSource.fetchPopularRecipes(category);
      return Right(models.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }
}

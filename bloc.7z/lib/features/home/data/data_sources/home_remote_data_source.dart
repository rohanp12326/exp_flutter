import 'package:my_project/core/network/dio_client.dart';
import 'package:my_project/features/home/data/models/category_model.dart';
import 'package:my_project/features/home/data/models/featured_model.dart';
import 'package:my_project/features/home/data/models/recipe_model.dart';

class HomeRemoteDataSource {
  final DioClient dioClient;

  HomeRemoteDataSource({required this.dioClient});

  Future<List<FeaturedModel>> fetchFeatured() async {
    await Future.delayed(const Duration(milliseconds: 500));
    return FeaturedModel.getMockedList();
  }

  Future<List<CategoryModel>> fetchCategories() async {
    await Future.delayed(const Duration(milliseconds: 300));
    return CategoryModel.getMockedList();
  }

  Future<List<RecipeModel>> fetchPopularRecipes(String category) async {
    await Future.delayed(const Duration(milliseconds: 500));
    return RecipeModel.getMockedListByCategory(category);
  }
}

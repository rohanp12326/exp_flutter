import 'package:my_project/core/constants/app_constants.dart';

enum Flavor { development, staging, production }

class FlavorConfig {
  final Flavor flavor;
  final String apiBaseUrl;

  FlavorConfig._internal({required this.flavor, required this.apiBaseUrl});

  static late FlavorConfig _instance;
  static FlavorConfig get instance => _instance;

  static Future<void> initialize({required Flavor flavor}) async {
    String baseUrl;
    switch (flavor) {
      case Flavor.production:
        baseUrl = AppConstants.productionBaseUrl;
        break;
      case Flavor.staging:
        baseUrl = AppConstants.stagingBaseUrl;
        break;
      default:
        baseUrl = AppConstants.developmentBaseUrl;
    }
    _instance = FlavorConfig._internal(flavor: flavor, apiBaseUrl: baseUrl);
  }
}

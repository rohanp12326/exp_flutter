import 'package:get_it/get_it.dart';
import 'package:my_project/core/network/dio_client.dart';
import 'package:my_project/features/home/data/data_sources/home_remote_data_source.dart';
import 'package:my_project/features/home/data/repositories/home_repository_impl.dart';
import 'package:my_project/features/home/domain/repositories/home_repository.dart';
import 'package:my_project/features/home/domain/usecases/get_categories_usecase.dart';
import 'package:my_project/features/home/domain/usecases/get_featured_usecase.dart';
import 'package:my_project/features/home/domain/usecases/get_popular_recipes_usecase.dart';
import 'package:my_project/features/home/presentation/combined_screens.dart';
import 'package:my_project/features/home/presentation/bloc/home_bloc.dart';

final sl = GetIt.instance;

Future<void> initInjector() async {
  final dioClient = await DioClient.create();
  sl.registerLazySingleton(() => dioClient);

  sl.registerLazySingleton(() => HomeRemoteDataSource(dioClient: sl()));
  sl.registerLazySingleton<HomeRepository>(() => HomeRepositoryImpl(remoteDataSource: sl()));

  sl.registerLazySingleton(() => GetFeaturedUseCase(repository: sl()));
  sl.registerLazySingleton(() => GetCategoriesUseCase(repository: sl()));
  sl.registerLazySingleton(() => GetPopularRecipesUseCase(repository: sl()));

  sl.registerFactory(() => HomeBloc(
        getFeaturedUseCase: sl(),
        getCategoriesUseCase: sl(),
        getPopularRecipesUseCase: sl(),
      ));
}

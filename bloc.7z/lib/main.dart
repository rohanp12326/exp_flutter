import 'package:flutter/material.dart';
import 'package:my_project/config/flavor_config.dart';
import 'package:my_project/core/constants/app_constants.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/text_styles.dart';
import 'package:my_project/injection/injector.dart';
import 'package:my_project/features/home/presentation/combined_screens.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FlavorConfig.initialize(flavor: Flavor.development);
  await initInjector();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appTitle,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: ColorPalette.primary),
        textTheme: TextStyles.textTheme,
      ),
      home: const CombinedScreens(),
    );
  }
}

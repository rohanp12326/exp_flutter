import 'package:dio/dio.dart';
import 'package:my_project/config/flavor_config.dart';
import 'package:my_project/core/error/exceptions.dart';

class DioClient {
  final Dio _dio;

  DioClient._internal(this._dio) {
    _dio
      ..options.baseUrl = FlavorConfig.instance.apiBaseUrl
      ..options.connectTimeout = const Duration(seconds: 15)
      ..options.receiveTimeout = const Duration(seconds: 15)
      ..interceptors.add(LogInterceptor(responseBody: true, requestBody: true))
      ..interceptors.add(InterceptorsWrapper(onError: (error, handler) {
        if (error.type == DioErrorType.connectionTimeout || error.type == DioErrorType.receiveTimeout) {
          handler.reject(DioError(requestOptions: error.requestOptions, error: NetworkException('Connection timeout')));
        }
        return handler.next(error);
      }));
  }

  static Future<DioClient> create() async {
    final dio = Dio();
    return DioClient._internal(dio);
  }

  Dio get instance => _dio;
}

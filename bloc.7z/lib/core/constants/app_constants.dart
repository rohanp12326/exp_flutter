class AppConstants {
  AppConstants._();
  static const String appTitle = 'Responsive UI';
  static const String developmentBaseUrl = 'https://dev.api.myproject.com';
  static const String stagingBaseUrl = 'https://staging.api.myproject.com';
  static const String productionBaseUrl = 'https://api.myproject.com';
}
import 'package:flutter/material.dart';

class ColorPalette {
  ColorPalette._();
  static const Color primary = Color.fromRGBO(111, 185, 190, 1);
  static const Color secondary = Color.fromRGBO(241, 245, 245, 1);
  static const Color background = Colors.white;
  static const Color textPrimary = Color.fromRGBO(10, 37, 51, 1);
  static const Color textSecondary = Color.fromRGBO(151, 161, 176, 1);
}

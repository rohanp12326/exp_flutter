import 'package:flutter/widgets.dart';

class SizeUtils {
  static double scaleWidth(BuildContext context, double inputWidth) {
    return MediaQuery.of(context).size.width * (inputWidth / 375);
  }

  static double scaleHeight(BuildContext context, double inputHeight) {
    return MediaQuery.of(context).size.height * (inputHeight / 812);
  }
}

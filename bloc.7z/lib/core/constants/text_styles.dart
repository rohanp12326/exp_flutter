import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';

class TextStyles {
  TextStyles._();
  static TextTheme get textTheme => const TextTheme(
        headlineSmall: TextStyle(fontWeight: FontWeight.w800, color: ColorPalette.textPrimary),
        titleMedium: TextStyle(fontWeight: FontWeight.normal, color: ColorPalette.textPrimary),
      );
}

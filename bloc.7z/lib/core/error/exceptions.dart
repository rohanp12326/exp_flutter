class NetworkException implements Exception {
  final String message;
  NetworkException([this.message = 'NetworkException']);
}

class ServerException implements Exception {
  final String message;
  ServerException([this.message = 'ServerException']);
}

import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';

class CategoryButton extends StatelessWidget {
  final String label;
  const CategoryButton({Key? key, required this.label}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;

    return Container(
      margin: EdgeInsets.symmetric(vertical: height * 0.01),
      decoration: BoxDecoration(
        color: ColorPalette.categoryBackground,
        borderRadius: BorderRadius.circular(height * 0.02),
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            color: ColorPalette.onSurface,
            fontSize: height * 0.02,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

import 'package:get/get.dart';
import 'package:my_project/core/constants/app_strings.dart';

class SocietiesController extends GetxController {
  final searchTerm = ''.obs;
  late final RxList<String> filteredCategories;
  final List<String> _allCategories = [
    AppString.technical,
    AppString.dance,
    AppString.music,
    AppString.art,
    AppString.drama,
    AppString.literary,
    AppString.photography,
    AppString.filmMedia,
    AppString.entrepreneurship,
    AppString.robotics,
    AppString.sports,
    AppString.debate,
    AppString.quiz,
    AppString.cultural,
  ];

  @override
  void onInit() {
    filteredCategories = _allCategories.obs;
    ever(searchTerm, (_) => _filterCategories());
    super.onInit();
  }

  void onSearchChanged(String value) {
    searchTerm.value = value;
  }

  void _filterCategories() {
    final term = searchTerm.value.toLowerCase();
    if (term.isEmpty) {
      filteredCategories.value = _allCategories;
    } else {
      filteredCategories.value = _allCategories
          .where((c) => c.toLowerCase().contains(term))
          .toList();
    }
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/app/app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const App());
}

class AppDimensions {
  static const double small = 8.0;
  static const double medium = 16.0;
  static const double large = 32.0;
  static const double radius = 16.0;
}
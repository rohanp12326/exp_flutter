class HttpService {
  // TODO: implement API integrations
}
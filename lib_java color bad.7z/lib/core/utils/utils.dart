import 'package:get/get.dart';

class Utils {
  static void showErrorMessage(String message) {
    Get.snackbar('Error', message, snackPosition: SnackPosition.BOTTOM);
  }
}

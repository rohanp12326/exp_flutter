import 'package:flutter/material.dart';

class ColorPalette {
  static const Color primary = Color(0xFF6200EE);
  static const Color secondary = Color(0xFF03DAC6);
  static const Color background = Color(0xFFE3F2FD);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color accent = Color(0xFFFFC107);
  static const Color drawerBackground = Color(0xFFBB86FC);
  static const Color buttonBackground = Color(0xFFFFEB3B);
}

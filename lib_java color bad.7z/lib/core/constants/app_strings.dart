class AppStrings {
  static const String appTitle = 'AMIVENTS';
  static const String societiesTitle = 'SOCIETIES';
  static const String searchHint = 'Search societies...';
  static const String navigation = 'Navigation';
  static const String home = 'Home';
  static const String settings = 'Settings';
}

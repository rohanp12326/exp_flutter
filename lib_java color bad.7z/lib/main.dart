import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_strings.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/modules/home_screen/bindings/home_binding.dart';
import 'package:my_project/modules/home_screen/presentation/home_screen_view.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: AppStrings.appTitle,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: ColorPalette.primary),
        useMaterial3: true,
      ),
      initialBinding: HomeBinding(),
      home: const HomeScreen(),
    );
  }
}

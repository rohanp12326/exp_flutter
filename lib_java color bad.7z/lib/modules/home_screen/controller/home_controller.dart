import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HomeController extends GetxController {
  final TextEditingController searchController = TextEditingController();

  final List<String> _societiesList = const [
    'TECHNICAL',
    'DANCE',
    'MUSIC',
    'ART',
    'DRAMA',
    'LITERARY',
    'PHOTOGRAPHY',
    'FILM & MEDIA',
    'ENTREPRENEURSHIP',
    'ROBOTICS',
    'SPORTS',
    'DEBATE',
    'QUIZ',
    'CULTURAL',
  ];

  final RxList<String> filteredSocieties = <String>[].obs;

  @override
  void onInit() {
    filteredSocieties.assignAll(_societiesList);
    searchController.addListener(_filterSocieties);
    super.onInit();
  }

  void _filterSocieties() {
    filteredSocieties.assignAll(
      _societiesList.where(
        (society) =>
            society.toLowerCase().contains(searchController.text.toLowerCase()),
      ),
    );
  }

  @override
  void onClose() {
    searchController.dispose();
    super.onClose();
  }
}

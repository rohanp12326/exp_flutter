import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/strings.dart';
import 'package:my_project/features/home/models/featured_recipe.dart';
import 'package:my_project/features/home/viewmodels/home_viewmodel.dart';
import 'package:my_project/features/home/views/widgets/featured_card.dart';

class FeaturedSection extends ConsumerWidget {
  const FeaturedSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final featuredRecipes = ref.watch(featuredRecipesProvider);
    final height = MediaQuery.of(context).size.height;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            Strings.featured,
            style: TextStyle(
              fontSize: height * 0.022,
              fontWeight: FontWeight.w800,
              color: ColorPalette.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: height * 0.25,
            child: Scrollbar(
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: EdgeInsets.zero,
                itemCount: featuredRecipes.length,
                itemBuilder: (context, index) {
                  final item = featuredRecipes[index];
                  return FeaturedCard(recipe: item);
                },
                separatorBuilder: (context, index) =>
                    const SizedBox(width: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/strings.dart';
import 'package:my_project/features/home/viewmodels/home_viewmodel.dart';
import 'package:my_project/features/home/views/widgets/category_button.dart';

class CategorySection extends ConsumerWidget {
  const CategorySection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedCategory = ref.watch(homeViewModelProvider);
    final height = MediaQuery.of(context).size.height;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                Strings.category,
                style: TextStyle(
                  fontSize: height * 0.022,
                  fontWeight: FontWeight.w800,
                  color: ColorPalette.textPrimary,
                ),
              ),
              GestureDetector(
                onTap: () {},
                child: Text(
                  Strings.seeAll,
                  style: TextStyle(
                    fontSize: height * 0.015,
                    fontWeight: FontWeight.w800,
                    color: ColorPalette.primary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Expanded(
                child: CategoryButton(
                  label: Strings.breakfast,
                  isSelected:
                      selectedCategory == Strings.breakfast,
                  onTap: () => ref
                      .read(homeViewModelProvider.notifier)
                      .selectCategory(Strings.breakfast),
                ),
              ),
              Expanded(
                child: CategoryButton(
                  label: Strings.lunch,
                  isSelected: selectedCategory == Strings.lunch,
                  onTap: () => ref
                      .read(homeViewModelProvider.notifier)
                      .selectCategory(Strings.lunch),
                ),
              ),
              Expanded(
                child: CategoryButton(
                  label: Strings.dinner,
                  isSelected: selectedCategory == Strings.dinner,
                  onTap: () => ref
                      .read(homeViewModelProvider.notifier)
                      .selectCategory(Strings.dinner),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

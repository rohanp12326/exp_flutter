import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/image_paths.dart';
import 'package:my_project/core/constants/strings.dart';

class CustomHeader extends StatelessWidget {
  const CustomHeader({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Image.asset(
                    ImagePaths.sunIcon,
                    height: height * 0.025,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    Strings.goodMorning,
                    style: TextStyle(
                      fontSize: height * 0.02,
                      fontWeight: FontWeight.normal,
                      color: ColorPalette.textPrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                Strings.userName,
                style: TextStyle(
                  fontSize: height * 0.027,
                  fontWeight: FontWeight.w800,
                  color: ColorPalette.textPrimary,
                ),
              ),
            ],
          ),
          Row(
            children: [
              IconButton(
                icon: Image.asset(ImagePaths.cartIcon),
                iconSize: height * 0.03,
                onPressed: () {},
              ),
              IconButton(
                icon: Image.asset(ImagePaths.profileIcon),
                iconSize: height * 0.03,
                onPressed: () {},
              ),
            ],
          ),
        ],
      ),
    );
  }
}

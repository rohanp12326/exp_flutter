import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/strings.dart';
import 'package:my_project/features/home/viewmodels/home_viewmodel.dart';
import 'package:my_project/features/home/views/widgets/recipe_card.dart';

class PopularRecipesSection extends ConsumerWidget {
  const PopularRecipesSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final popularRecipes = ref.watch(popularRecipesProvider);
    final height = MediaQuery.of(context).size.height;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                Strings.popularRecipes,
                style: TextStyle(
                  fontSize: height * 0.022,
                  fontWeight: FontWeight.w800,
                  color: ColorPalette.textPrimary,
                ),
              ),
              GestureDetector(
                onTap: () {},
                child: Text(
                  Strings.seeAll,
                  style: TextStyle(
                    fontSize: height * 0.015,
                    fontWeight: FontWeight.w800,
                    color: ColorPalette.primary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: height * 0.25,
            child: Scrollbar(
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: EdgeInsets.zero,
                itemCount: popularRecipes.length,
                itemBuilder: (context, index) {
                  final item = popularRecipes[index];
                  return RecipeCard(recipe: item);
                },
                separatorBuilder: (context, index) =>
                    const SizedBox(width: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

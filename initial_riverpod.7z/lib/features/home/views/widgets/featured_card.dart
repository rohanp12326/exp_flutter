import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/image_paths.dart';
import 'package:my_project/features/home/models/featured_recipe.dart';

class FeaturedCard extends StatelessWidget {
  final FeaturedRecipe recipe;
  const FeaturedCard({Key? key, required this.recipe}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return GestureDetector(
      onTap: () {},
      child: AspectRatio(
        aspectRatio: 16 / 9,
        child: Container(
          decoration: BoxDecoration(
            color: ColorPalette.primary,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Stack(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.asset(
                  recipe.imagePath,
                  fit: BoxFit.cover,
                  width: double.infinity,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      recipe.title,
                      style: TextStyle(
                        fontSize: height * 0.02,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const Spacer(),
                    Row(
                      children: [
                        CircleAvatar(
                          radius: height * 0.015,
                          backgroundImage:
                              AssetImage(ImagePaths.userImage1),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          recipe.creator,
                          style: TextStyle(
                            fontSize: height * 0.015,
                            color: Colors.white,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          recipe.time,
                          style: TextStyle(
                            fontSize: height * 0.015,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

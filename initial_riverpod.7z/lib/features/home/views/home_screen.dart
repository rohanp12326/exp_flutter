import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_project/core/constants/strings.dart';
import 'package:my_project/features/home/views/widgets/custom_header.dart';
import 'package:my_project/features/home/views/widgets/featured_section.dart';
import 'package:my_project/features/home/views/widgets/category_section.dart';
import 'package:my_project/features/home/views/widgets/popular_recipes_section.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SafeArea(
      child: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            child: ConstrainedBox(
              constraints:
                  BoxConstraints(minHeight: constraints.maxHeight),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: const [
                  CustomHeader(),
                  SizedBox(height: 16),
                  FeaturedSection(),
                  SizedBox(height: 16),
                  CategorySection(),
                  SizedBox(height: 16),
                  PopularRecipesSection(),
                  SizedBox(height: 80),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_project/core/constants/strings.dart';
import 'package:my_project/core/constants/image_paths.dart';
import 'package:my_project/features/home/models/featured_recipe.dart';
import 'package:my_project/features/home/models/recipe.dart';

class HomeViewModel extends StateNotifier<String> {
  HomeViewModel() : super(Strings.breakfast);

  void selectCategory(String category) => state = category;
}

final homeViewModelProvider =
    StateNotifierProvider<HomeViewModel, String>((ref) {
  return HomeViewModel();
});

final featuredRecipesProvider = Provider<List<FeaturedRecipe>>((ref) {
  return const [
    FeaturedRecipe(
      imagePath: ImagePaths.featuredCard1,
      title: 'Asian white noodle with extra seafood',
      creator: 'James Spader',
      time: '20 Min',
    ),
    FeaturedRecipe(
      imagePath: ImagePaths.featuredCard2,
      title: 'Healthy Taco Salad with fresh vegetable',
      creator: 'Olivia Rizka',
      time: '15 Min',
    ),
  ];
});

final popularRecipesProvider = Provider<List<Recipe>>((ref) {
  final category = ref.watch(homeViewModelProvider);
  switch (category) {
    case Strings.breakfast:
      return const [
        Recipe(
          imagePath: ImagePaths.popularRecipe1,
          title: 'Healthy Taco Salad with fresh vegetable',
          calories: '120 Kcal',
          time: '20 Min',
        ),
        Recipe(
          imagePath: ImagePaths.popularRecipe2,
          title: 'Japanese-style Pancakes Recipe',
          calories: '64 Kcal',
          time: '12 Min',
        ),
      ];
    case Strings.lunch:
      return const [
        Recipe(
          imagePath: ImagePaths.popularRecipe3,
          title: 'Grilled Chicken Salad',
          calories: '200 Kcal',
          time: '25 Min',
        ),
        Recipe(
          imagePath: ImagePaths.popularRecipe4,
          title: 'Pasta Primavera',
          calories: '350 Kcal',
          time: '30 Min',
        ),
      ];
    case Strings.dinner:
      return const [
        Recipe(
          imagePath: ImagePaths.popularRecipe1,
          title: 'Steak with Vegetables',
          calories: '500 Kcal',
          time: '40 Min',
        ),
        Recipe(
          imagePath: ImagePaths.popularRecipe2,
          title: 'Seafood Paella',
          calories: '600 Kcal',
          time: '50 Min',
        ),
      ];
    default:
      return const [];
  }
});

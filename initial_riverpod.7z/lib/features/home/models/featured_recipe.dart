class FeaturedRecipe {
  final String imagePath;
  final String title;
  final String creator;
  final String time;

  const FeaturedRecipe({
    required this.imagePath,
    required this.title,
    required this.creator,
    required this.time,
  });
}

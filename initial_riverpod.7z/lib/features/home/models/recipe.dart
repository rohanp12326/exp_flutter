class Recipe {
  final String imagePath;
  final String title;
  final String calories;
  final String time;

  const Recipe({
    required this.imagePath,
    required this.title,
    required this.calories,
    required this.time,
  });
}

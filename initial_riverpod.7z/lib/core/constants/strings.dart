class Strings {
  static const appTitle = 'Responsive UI';
  static const goodMorning = 'Good Morning';
  static const userName = 'Alena Sabyan';
  static const featured = 'Featured';
  static const category = 'Category';
  static const popularRecipes = 'Popular Recipes';
  static const seeAll = 'See All';
  static const breakfast = 'Breakfast';
  static const lunch = 'Lunch';
  static const dinner = 'Dinner';
}

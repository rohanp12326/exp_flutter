class ImagePaths {
  static const sunIcon = 'assets/images/sun_icon.png';
  static const cartIcon = 'assets/images/cart_icon.png';
  static const profileIcon = 'assets/images/bottom_profile_icon.png';
  static const featuredCard1 = 'assets/images/featured_card_1.png';
  static const featuredCard2 = 'assets/images/featured_card_2.png';
  static const userImage1 = 'assets/images/user_image_1.png';
  static const popularRecipe1 = 'assets/images/popular_recipe1.png';
  static const popularRecipe2 = 'assets/images/popular_recipe2.png';
  static const popularRecipe3 = 'assets/images/popular_recipe3.png';
  static const popularRecipe4 = 'assets/images/popular_recipe4.png';
  static const favouriteIcon = 'assets/images/favourite_icon.png';
  static const caloriesIcon = 'assets/images/calories_icon.png';
  static const proteinsIcon = 'assets/images/proteins_icon.png';
  static const bottomHomeIcon = 'assets/images/bottom_home_icon.png';
  static const bottomSearchIcon = 'assets/images/bottom_search_icon.png';
  static const bottomNotificationsIcon = 'assets/images/bottom_notifications_icon.png';
  static const chefIcon = 'assets/images/chef_icon.png';
}

import 'package:flutter/material.dart';
import 'package:my_project/core/constants/image_paths.dart';

class CustomFloatingButton extends StatelessWidget {
  const CustomFloatingButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final sizeFactor = MediaQuery.of(context).size.height * 0.063;
    return Container(
      width: sizeFactor,
      height: sizeFactor,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        color: Color.fromRGBO(3, 38, 40, 1),
        boxShadow: [
          BoxShadow(
            color: Color.fromRGBO(3, 3, 25, 0.2),
            offset: Offset(0, 0),
            blurRadius: 30,
          ),
        ],
      ),
      child: Center(
        child: Image.asset(
          ImagePaths.chefIcon,
          height: MediaQuery.of(context).size.height * 0.03,
        ),
      ),
    );
  }
}
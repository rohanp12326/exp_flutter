import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/image_paths.dart';
import 'package:my_project/widgets/nav_bar_item.dart';

class CustomBottomNavBar extends StatelessWidget {
  const CustomBottomNavBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Container(
      height: height * 0.1,
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Color.fromRGBO(149, 168, 195, 0.15),
            offset: Offset(0, -10),
            blurRadius: 40,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          NavBarItem(imagePath: ImagePaths.bottomHomeIcon),
          NavBarItem(imagePath: ImagePaths.bottomSearchIcon),
          SizedBox(width: MediaQuery.of(context).size.width * 0.2),
          NavBarItem(imagePath: ImagePaths.bottomNotificationsIcon),
          NavBarItem(imagePath: ImagePaths.profileIcon),
        ],
      ),
    );
  }
}

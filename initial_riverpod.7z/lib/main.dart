import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_project/combined_screens.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/core/constants/strings.dart';

void main() {
  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: Strings.appTitle,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: ColorPalette.primary,
        ),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      home: const CombinedScreens(),
    );
  }
}

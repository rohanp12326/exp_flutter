import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_project/features/home/views/home_screen.dart';
import 'package:my_project/widgets/custom_bottom_nav_bar.dart';
import 'package:my_project/widgets/custom_floating_button.dart';

class CombinedScreens extends ConsumerWidget {
  const CombinedScreens({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return const Scaffold(
      body: HomeScreen(),
      bottomNavigationBar: CustomBottomNavBar(),
      floatingActionButton: CustomFloatingButton(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}

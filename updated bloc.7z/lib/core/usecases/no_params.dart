class NoParams {}

class LocalDataException implements Exception {
  final String message;
  LocalDataException(this.message);
}

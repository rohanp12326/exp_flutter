class AppDimens {
  static const double borderRadius = 16;
  static const double categoryBorderRadius = 32;
  static const double bottomBarBlurRadius = 40;
  static const double bottomBarOffset = 10;
  static const double cardOverlayPadding = 16;
}

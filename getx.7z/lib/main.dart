import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_colors.dart';
import 'package:my_project/core/constants/app_strings.dart';
import 'package:my_project/modules/home/bindings/home_binding.dart';
import 'package:my_project/modules/home/presentations/screens/combined_screens.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: AppStrings.appTitle,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: const ColorScheme(
          brightness: Brightness.light,
          primary: AppColors.primary,
          onPrimary: AppColors.onPrimary,
          secondary: AppColors.secondary,
          onSecondary: AppColors.onSecondary,
          surface: AppColors.surface,
          onSurface: AppColors.onSurface,
          background: AppColors.background,
          onBackground: AppColors.onBackground,
          error: AppColors.error,
          onError: AppColors.onError,
        ),
        fontFamily: 'Roboto',
      ),
      initialBinding: HomeBinding(),
      home: const CombinedScreens(),
    );
  }
}

import 'package:get/get.dart';
import 'package:my_project/core/constants/app_strings.dart';

class HomeController extends GetxController {
  final selectedCategory = AppStrings.breakfast.obs;

  void selectCategory(String category) {
    selectedCategory.value = category;
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_dimensions.dart';
import 'package:my_project/modules/home/controllers/home_controller.dart';
import 'package:my_project/modules/home/presentations/widgets/category_section.dart';
import 'package:my_project/modules/home/presentations/widgets/custom_header.dart';
import 'package:my_project/modules/home/presentations/widgets/featured_section.dart';
import 'package:my_project/modules/home/presentations/widgets/popular_recipes_section.dart';

class HomeScreen extends GetView<HomeController> {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: LayoutBuilder(builder: (context, constraints) {
        return SingleChildScrollView(
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.maxHeight),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const CustomHeader(),
                SizedBox(height: constraints.maxHeight * 0.02),
                const FeaturedSection(),
                SizedBox(height: constraints.maxHeight * 0.02),
                Obx(
                  () => CategorySection(
                    selectedCategory: controller.selectedCategory.value,
                    onCategorySelected: controller.selectCategory,
                  ),
                ),
                SizedBox(height: constraints.maxHeight * 0.02),
                Obx(
                  () => PopularRecipesSection(
                    selectedCategory: controller.selectedCategory.value,
                  ),
                ),
                SizedBox(height: constraints.maxHeight * 0.1),
              ],
            ),
          ),
        );
      }),
    );
  }
}

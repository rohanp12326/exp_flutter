import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/modules/home/controllers/home_controller.dart';
import 'package:my_project/modules/home/presentations/widgets/custom_bottom_nav_bar.dart';
import 'package:my_project/modules/home/presentations/widgets/custom_floating_button.dart';
import 'package:my_project/modules/home/presentations/screens/home_screen.dart';

class CombinedScreens extends GetView<HomeController> {
  const CombinedScreens({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: const HomeScreen(),
      bottomNavigationBar: const CustomBottomNavBar(),
      floatingActionButton: const CustomFloatingButton(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}

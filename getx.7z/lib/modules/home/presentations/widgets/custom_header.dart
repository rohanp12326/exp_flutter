import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_dimensions.dart';
import 'package:my_project/core/constants/app_images.dart';
import 'package:my_project/core/constants/app_strings.dart';

class CustomHeader extends StatelessWidget {
  const CustomHeader({super.key});
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimensions.padding,
        vertical: AppDimensions.paddingSmall,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Image.asset(
                    AppImages.sunIcon,
                    height: height * 0.025,
                  ),
                  const SizedBox(width: AppDimensions.paddingSmall),
                  Text(
                    AppStrings.goodMorning,
                    style: context.textTheme.bodyLarge?.copyWith(
                      color: context.theme.colorScheme.onBackground,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppDimensions.paddingSmall / 2),
              Text(
                AppStrings.userName,
                style: context.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                  color: context.theme.colorScheme.onBackground,
                ),
              ),
            ],
          ),
          Row(
            children: [
              IconButton(
                icon: Image.asset(AppImages.cartIcon),
                iconSize: height * 0.03,
                onPressed: () {},
              ),
              IconButton(
                icon: Image.asset(AppImages.profileIcon),
                iconSize: height * 0.03,
                onPressed: () {},
              ),
            ],
          ),
        ],
      ),
    );
  }
}

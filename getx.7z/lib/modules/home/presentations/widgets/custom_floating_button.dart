import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_dimensions.dart';
import 'package:my_project/core/constants/app_images.dart';

class CustomFloatingButton extends StatelessWidget {
  const CustomFloatingButton({super.key});
  @override
  Widget build(BuildContext context) {
    final sizeFactor = MediaQuery.of(context).size.height * AppDimensions.fabSizeFactor;
    return Container(
      width: sizeFactor,
      height: sizeFactor,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: context.theme.colorScheme.primary,
        boxShadow: const [
          BoxShadow(
            color: Color.fromRGBO(3, 3, 25, 0.2),
            offset: Offset(0, 0),
            blurRadius: 30,
          ),
        ],
      ),
      child: Center(
        child: Image.asset(
          AppImages.chefIcon,
          height: MediaQuery.of(context).size.height * 0.03,
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_dimensions.dart';
import 'package:my_project/core/constants/app_strings.dart';
import 'package:my_project/modules/home/presentations/widgets/category_button.dart';

class CategorySection extends StatelessWidget {
  final String selectedCategory;
  final Function(String) onCategorySelected;
  const CategorySection({
    required this.selectedCategory,
    required this.onCategorySelected,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppDimensions.padding),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                AppStrings.category,
                style: context.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
              ),
              GestureDetector(
                onTap: () {},
                child: Text(
                  AppStrings.seeAll,
                  style: context.textTheme.bodyMedium?.copyWith(
                    color: context.theme.colorScheme.secondary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppDimensions.paddingSmall),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              CategoryButton(
                label: AppStrings.breakfast,
                isSelected: selectedCategory == AppStrings.breakfast,
                onTap: () => onCategorySelected(AppStrings.breakfast),
              ),
              CategoryButton(
                label: AppStrings.lunch,
                isSelected: selectedCategory == AppStrings.lunch,
                onTap: () => onCategorySelected(AppStrings.lunch),
              ),
              CategoryButton(
                label: AppStrings.dinner,
                isSelected: selectedCategory == AppStrings.dinner,
                onTap: () => onCategorySelected(AppStrings.dinner),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

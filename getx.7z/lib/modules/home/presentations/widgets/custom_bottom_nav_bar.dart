import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_dimensions.dart';
import 'package:my_project/core/constants/app_images.dart';
import 'package:my_project/modules/home/presentations/widgets/nav_bar_item.dart';

class CustomBottomNavBar extends StatelessWidget {
  const CustomBottomNavBar({super.key});
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Container(
      height: height * AppDimensions.navBarHeightFactor,
      decoration: BoxDecoration(
        color: context.theme.colorScheme.surface,
        boxShadow: const [
          BoxShadow(
            color: Color.fromRGBO(149, 168, 195, 0.15),
            offset: Offset(0, -10),
            blurRadius: 40,
          )
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: const [
          NavBarItem(imagePath: AppImages.bottomHomeIcon),
          NavBarItem(imagePath: AppImages.bottomSearchIcon),
          SizedBox(width: 60),
          NavBarItem(imagePath: AppImages.bottomNotificationsIcon),
          NavBarItem(imagePath: AppImages.profileIcon),
        ],
      ),
    );
  }
}

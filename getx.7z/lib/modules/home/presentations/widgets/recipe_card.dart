import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_dimensions.dart';
import 'package:my_project/core/constants/app_images.dart';

class RecipeCard extends StatelessWidget {
  final String imagePath;
  final String title;
  final String calories;
  final String time;
  const RecipeCard({
    required this.imagePath,
    required this.title,
    required this.calories,
    required this.time,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return GestureDetector(
      onTap: () {},
      child: AspectRatio(
        aspectRatio: 3 / 4,
        child: Container(
          decoration: BoxDecoration(
            color: context.theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(AppDimensions.borderRadius),
            boxShadow: const [
              BoxShadow(
                color: Color.fromRGBO(5, 51, 54, 0.1),
                offset: Offset(0, 2),
                blurRadius: 16,
              )
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                flex: 6,
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius:
                          const BorderRadius.vertical(top: Radius.circular(AppDimensions.borderRadius)),
                      child: Image.asset(
                        imagePath,
                        fit: BoxFit.cover,
                      ),
                    ),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: GestureDetector(
                        onTap: () {},
                        child: Image.asset(
                          AppImages.favouriteIcon,
                          height: height * 0.03,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 4,
                child: Padding(
                  padding: const EdgeInsets.all(AppDimensions.paddingSmall),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: context.textTheme.bodyLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: context.theme.colorScheme.onSurface,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const Spacer(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Image.asset(
                                AppImages.caloriesIcon,
                                height: height * 0.02,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                calories,
                                style: context.textTheme.bodyMedium?.copyWith(
                                  color: const Color.fromRGBO(151, 161, 176, 1),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Image.asset(
                                AppImages.proteinsIcon,
                                height: height * 0.02,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                time,
                                style: context.textTheme.bodyMedium?.copyWith(
                                  color: const Color.fromRGBO(151, 161, 176, 1),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

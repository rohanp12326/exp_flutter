import 'package:flutter/material.dart';

class NavBarItem extends StatelessWidget {
  final String imagePath;
  const NavBarItem({required this.imagePath, super.key});
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Image.asset(
      imagePath,
      height: height * 0.03,
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_dimensions.dart';
import 'package:my_project/core/constants/app_images.dart';
import 'package:my_project/modules/home/presentations/widgets/recipe_card.dart';

class PopularRecipesSection extends StatelessWidget {
  final String selectedCategory;
  const PopularRecipesSection({
    required this.selectedCategory,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppDimensions.padding),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Popular Recipes',
                style: context.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
              ),
              GestureDetector(
                onTap: () {},
                child: Text(
                  'See All',
                  style: context.textTheme.bodyMedium?.copyWith(
                    color: context.theme.colorScheme.secondary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppDimensions.paddingSmall),
          SizedBox(
            height: height * 0.25,
            child: Scrollbar(
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  if (selectedCategory == 'Breakfast') ...[
                    const RecipeCard(
                      imagePath: AppImages.popularRecipe1,
                      title: 'Healthy Taco Salad with fresh vegetable',
                      calories: '120 Kcal',
                      time: '20 Min',
                    ),
                    const SizedBox(width: AppDimensions.padding),
                    const RecipeCard(
                      imagePath: AppImages.popularRecipe2,
                      title: 'Japanese-style Pancakes Recipe',
                      calories: '64 Kcal',
                      time: '12 Min',
                    ),
                  ] else if (selectedCategory == 'Lunch') ...[
                    const RecipeCard(
                      imagePath: AppImages.popularRecipe3,
                      title: 'Grilled Chicken Salad',
                      calories: '200 Kcal',
                      time: '25 Min',
                    ),
                    const SizedBox(width: AppDimensions.padding),
                    const RecipeCard(
                      imagePath: AppImages.popularRecipe4,
                      title: 'Pasta Primavera',
                      calories: '350 Kcal',
                      time: '30 Min',
                    ),
                  ] else if (selectedCategory == 'Dinner') ...[
                    const RecipeCard(
                      imagePath: AppImages.popularRecipe1,
                      title: 'Steak with Vegetables',
                      calories: '500 Kcal',
                      time: '40 Min',
                    ),
                    const SizedBox(width: AppDimensions.padding),
                    const RecipeCard(
                      imagePath: AppImages.popularRecipe2,
                      title: 'Seafood Paella',
                      calories: '600 Kcal',
                      time: '50 Min',
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

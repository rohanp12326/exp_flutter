import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_dimensions.dart';
import 'package:my_project/core/constants/app_images.dart';
import 'package:my_project/core/constants/app_strings.dart';
import 'package:my_project/modules/home/presentations/widgets/featured_card.dart';

class FeaturedSection extends StatelessWidget {
  const FeaturedSection({super.key});
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppDimensions.padding),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            AppStrings.featured,
            style: context.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: AppDimensions.paddingSmall),
          SizedBox(
            height: height * 0.25,
            child: Scrollbar(
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: const [
                  FeaturedCard(
                    imagePath: AppImages.featuredCard1,
                    title: 'Asian white noodle with extra seafood',
                    creator: 'James Spader',
                    time: '20 Min',
                  ),
                  SizedBox(width: AppDimensions.padding),
                  FeaturedCard(
                    imagePath: AppImages.featuredCard2,
                    title: 'Healthy Taco Salad with fresh vegetable',
                    creator: 'Olivia Rizka',
                    time: '15 Min',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

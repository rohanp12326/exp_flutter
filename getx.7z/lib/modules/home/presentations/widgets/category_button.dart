import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_dimensions.dart';

class CategoryButton extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  const CategoryButton({
    required this.label,
    required this.isSelected,
    required this.onTap,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: AppDimensions.paddingSmall / 2),
          padding: const EdgeInsets.symmetric(vertical: AppDimensions.paddingSmall),
          decoration: BoxDecoration(
            color: isSelected
                ? context.theme.colorScheme.secondary
                : const Color(0xFFF1F5F5),
            borderRadius: BorderRadius.circular(AppDimensions.borderRadius * 2),
          ),
          child: Center(
            child: Text(
              label,
              style: context.textTheme.bodyMedium?.copyWith(
                color: isSelected
                    ? context.theme.colorScheme.onSecondary
                    : context.theme.colorScheme.onBackground,
                fontSize: height * 0.018,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

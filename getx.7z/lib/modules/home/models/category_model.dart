class CategoryModel {
  final String label;
  CategoryModel({required this.label});
}

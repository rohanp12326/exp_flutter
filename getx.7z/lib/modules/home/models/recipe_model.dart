class RecipeModel {
  final String imagePath;
  final String title;
  final String creator;
  final String calories;
  final String time;

  RecipeModel({
    required this.imagePath,
    required this.title,
    this.creator = '',
    required this.calories,
    required this.time,
  });
}

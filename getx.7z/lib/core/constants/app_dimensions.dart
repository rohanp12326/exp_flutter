class AppDimensions {
  static const double paddingSmall = 8.0;
  static const double padding = 16.0;
  static const double borderRadius = 16.0;
  static const double navBarHeightFactor = 0.1;
  static const double fabSizeFactor = 0.063;
}

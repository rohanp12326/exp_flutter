import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF032628);
  static const Color onPrimary = Colors.white;
  static const Color secondary = Color(0xFF6FB9BE);
  static const Color onSecondary = Colors.white;
  static const Color surface = Colors.white;
  static const Color onSurface = Color(0xFF0A2533);
  static const Color background = Color(0xFFF1F5F5);
  static const Color onBackground = Color(0xFF0A2533);
  static const Color error = Colors.red;
  static const Color onError = Colors.white;
}

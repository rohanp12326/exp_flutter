class AppStrings {
  static const String appTitle = 'Responsive UI';
  static const String goodMorning = 'Good Morning';
  static const String userName = 'Alena Sabyan';
  static const String featured = 'Featured';
  static const String category = 'Category';
  static const String seeAll = 'See All';
  static const String popularRecipes = 'Popular Recipes';
  static const String breakfast = 'Breakfast';
  static const String lunch = 'Lunch';
  static const String dinner = 'Dinner';
}

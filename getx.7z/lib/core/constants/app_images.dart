class AppImages {
  static const String sunIcon = 'assets/images/sun_icon.png';
  static const String cartIcon = 'assets/images/cart_icon.png';
  static const String profileIcon = 'assets/images/bottom_profile_icon.png';
  static const String featuredCard1 = 'assets/images/featured_card_1.png';
  static const String featuredCard2 = 'assets/images/featured_card_2.png';
  static const String userImage1 = 'assets/images/user_image_1.png';
  static const String popularRecipe1 = 'assets/images/popular_recipe1.png';
  static const String popularRecipe2 = 'assets/images/popular_recipe2.png';
  static const String popularRecipe3 = 'assets/images/popular_recipe3.png';
  static const String popularRecipe4 = 'assets/images/popular_recipe4.png';
  static const String favouriteIcon = 'assets/images/favourite_icon.png';
  static const String caloriesIcon = 'assets/images/calories_icon.png';
  static const String proteinsIcon = 'assets/images/proteins_icon.png';
  static const String bottomHomeIcon = 'assets/images/bottom_home_icon.png';
  static const String bottomSearchIcon = 'assets/images/bottom_search_icon.png';
  static const String bottomNotificationsIcon = 'assets/images/bottom_notifications_icon.png';
  static const String chefIcon = 'assets/images/chef_icon.png';
}

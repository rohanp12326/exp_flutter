class ErrorHandler {
  static String getErrorMessage(Exception e) {
    return 'An unexpected error occurred';
  }
}
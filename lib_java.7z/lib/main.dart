import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_project/core/constants/app_strings.dart';
import 'package:my_project/core/constants/color_palette.dart';
import 'package:my_project/routes/app_pages.dart';
import 'package:my_project/routes/app_routes.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: AppStrings.appTitle,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: ColorPalette.primary),
      ),
      initialRoute: Routes.home,
      getPages: AppPages.pages,
    );
  }
}
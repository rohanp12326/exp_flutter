import 'package:get/get.dart';
import 'package:my_project/modules/home_screen/bindings/home_binding.dart';
import 'package:my_project/modules/home_screen/views/home_screen.dart';
import 'package:my_project/routes/app_routes.dart';

class AppPages {
  static final pages = [
    GetPage(
      name: Routes.home,
      page: () => const HomeScreen(),
      binding: HomeBinding(),
    ),
  ];
}
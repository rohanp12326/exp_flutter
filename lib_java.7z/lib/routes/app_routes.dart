abstract class Routes {
  static const String home = '/home';
}
class AppStrings {
  static const String appTitle = 'AMIVENTS';
  static const String menu = 'Menu';
  static const String drawerHome = 'Home';
  static const String drawerSettings = 'Settings';
  static const String societiesTitle = 'SOCIETIES';
  static const String footerText = 'Flying beyond the horizon of academics...';
}
import 'package:flutter/material.dart';

class ColorPalette {
  static const Color primary = Color.fromRGBO(69, 135, 206, 1);
  static const Color accent = Color.fromRGBO(250, 238, 192, 1);
  static const Color headline = Color.fromRGBO(45, 35, 12, 1);
  static const Color text = Color.fromRGBO(41, 96, 155, 1);
  static const Color listItemText = Color.fromRGBO(108, 99, 71, 1);
  static const Color appBar = Colors.purple;
}
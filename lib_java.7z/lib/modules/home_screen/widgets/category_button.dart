import 'package:flutter/material.dart';
import 'package:my_project/core/constants/color_palette.dart';

class CategoryButton extends StatelessWidget {
  final String label;
  const CategoryButton({Key? key, required this.label}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(50.0),
      child: Container(
        color: ColorPalette.accent,
        child: Center(
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: ColorPalette.listItemText,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
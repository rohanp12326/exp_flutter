import 'package:get/get.dart';
import 'package:my_project/modules/home_screen/models/category_model.dart';

class HomeController extends GetxController {
  final List<Category> categories = const [
    Category(label: 'TECHNICAL'),
    Category(label: 'DANCE'),
    Category(label: 'MUSIC'),
    Category(label: 'ART'),
    Category(label: 'DRAMA'),
    Category(label: 'LITERARY'),
  ];
}
class Category {
  final String label;
  const Category({required this.label});
}